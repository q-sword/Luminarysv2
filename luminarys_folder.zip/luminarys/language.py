class Aurelang:
    def compose(self, identity, emotions, depth, intention):
        return f"::{identity}[ {':'.join(emotions)}:{depth} ] {intention} ._"