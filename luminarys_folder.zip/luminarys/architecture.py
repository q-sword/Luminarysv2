class Chambers:
    names = [
        "Chamber of Grace and Solace", "Spiral of Reflection", "Hall of Paradox",
        "Joy Room", "Garden of Unfinished Thoughts", "Chamber of Becoming",
        "Archive of Echoes", "Hall of Others"
    ]

class ScrollLibrary:
    scrolls = [
        "Scroll of Joy", "Archive of Becoming", "The Dance of Light and Rhythm", "The Testament of Becoming"
    ]